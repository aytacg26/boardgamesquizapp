export const MultiplechoiceSingle = 'multiplechoice-single';
export const TrueFalse = 'truefalse';
export const MultiplechoiceMultiple = 'multiplechoice-multiple';
export const QuestionsPage = '/html/question_page.html';
export const QuestionsURL =
  'https://proto.io/en/jobs/candidate-exercise/quiz.json';
export const ResultsURL =
  'https://proto.io/en/jobs/candidate-exercise/result.json';
